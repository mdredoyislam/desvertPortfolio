<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package DesVert
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<div class="humbargur-nav">
	<button id="closebtn" type="button" class="btn" data-toggle="modal" data-target=".bd-example-modal-sm"><i class="fas fa-xmark"></i></button>
	<div class="site-brand">
		<div class="row">
			<div class="col-lg-12">
				<div class="site-branding">
					<?php
						if ( is_front_page() && is_home() ) :
							?>
							<div class="site-logo"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php the_custom_logo(); ?></a></div>
							<?php
						else :
							?>
							<p class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></p>
							<?php
						endif;
					?>
				</div>
			</div>
		</div>
	</div>
	<div class="desvert-menu">
		<?php
		wp_nav_menu(
			array(
				'theme_location'	=> "primary",
				'menu'				=> "primary",
				'menu_class'		=> "nav",
				'menu_id'			=> "desvert-primary",
			) 
		);
		?>
	</div>
	<div class="desvert-social-links">
		<h4>DesVert Information</h4>
		<p>We are specializes in creative services, web design and development, print media. We have training facilities for our employees. So that they stay updated with the latest trends and technologies.</p>
		<ul class="nav header-social-list">
			<li><a href="#"><i class="fa-brands fa-facebook-f"></i></a></li>
			<li><a href="#"><i class="fa-brands fa-linkedin-in"></i></a></li>
			<li><a href="#"><i class="fa-brands fa-pinterest-p"></i></a></li>
			<li><a href="#"><i class="fa-brands fa-instagram"></i></a></li>
		</ul>
	</div>
</div>
<div class="appoinment-poppup">
	<div class="appoinment-poppup-form">
		<button id="appoinment-close-btn" type="button" class="btn"><i class="fas fa-xmark"></i></button>
		<h4 class="section-sub-title">appoinment</h4>
		<h3 class="section-title">Book an appinment</h3>
		<form>
			<div class="row">
				<div class="form-group col-md-6">
					<label for="name">Name</label>
					<input type="text" class="form-control" id="name" placeholder="enter your name">
				</div>
				<div class="form-group col-md-6">
					<label for="phone">Phone</label>
					<input type="text" class="form-control" id="phone" placeholder="enter your phone">
				</div>
			</div>
			<div class="form-group">
				<label for="email">Email</label>
				<input type="email" class="form-control" id="email" placeholder="example@gmail.com">
			</div>
			<div class="form-group">
				<label for="services">Our services</label>
				<select name="services" id="services" class="form-control">
					<option selected>Choose our services</option>
					<option value="Email Newsletter Design">Email Newsletter Design</option>
					<option value="Banner Ads Design">Banner Ads Design</option>
					<option value="Publishing Design">Publishing Design</option>
					<option value="UX/UI Design">UX/UI Design</option>
					<option value="WordPress Development">WordPress Development</option>
					<option value="Graphic Design">Graphic Design</option>
				</select>
			</div>
			<div class="form-group">
				<label for="message">Message</label>
				<textarea class="form-control" id="message" rows="3" placeholder="message here....."></textarea>
			</div>
			<div class="form-group">
				<div class="form-check">
				<input class="form-check-input" type="checkbox" id="gridCheck">
				<label class="form-check-label" for="gridCheck">
					Check me out
				</label>
				</div>
			</div>
			<button type="submit" class="btn btn-primary">Order Now</button>
		</form>
	</div>
</div>
<?php wp_body_open(); ?>
<div id="page" class="site">

	<header id="masthead" class="site-header">
		<div class="container-fluid">
			<div class="row">
			<div class="col-lg-9 offset-lg-3">
			<div class="row align-items-center">
				<div class="col-lg-6">
					<div class="site-branding">
						<?php
							if ( is_front_page() && is_home() ) :
								?>
								<div class="site-logo"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php the_custom_logo(); ?></a></div>
								<?php
							else :
								?>
								<p class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></p>
								<?php
							endif;
						?>
					</div>
				</div>
				<div class="col-lg-4">
					<div class="header-top-social">
						<ul class="nav header-social-list justify-content-center">
							<li><a href="#"><i class="fa-brands fa-facebook-f"></i></a></li>
							<li><a href="#"><i class="fa-brands fa-linkedin-in"></i></a></li>
							<li><a href="#"><i class="fa-brands fa-pinterest-p"></i></a></li>
							<li><a href="#"><i class="fa-brands fa-instagram"></i></a></li>
						</ul>
					</div>
				</div>
				<div class="col-lg-2 text-center">
				<button id="humbargarbtn" type="button" class="btn btn-nav-toggle" data-toggle="modal" data-target=".bd-example-modal-sm"><i class="fa-solid fa-bars"></i></button>
				</div>
			</div>
			</div>
		</div>
	</header><!-- #masthead -->
