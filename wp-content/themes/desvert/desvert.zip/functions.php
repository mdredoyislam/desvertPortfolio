<?php
require_once( get_theme_file_path( 'inc/tgm.php' ) );
require get_template_directory()."/inc/desvert_theme_setup.php";
require get_template_directory()."/inc/desvert_enquee_script.php";
require get_template_directory()."/inc/desvert_register_sidebar.php";
require get_template_directory()."/inc/desvert_menu_filter.php";
require get_template_directory()."/inc/desvert_custom_header.php";
require get_template_directory()."/lib/redux-core/framework.php";
require get_template_directory()."/lib/sample/config.php";
//Redux Plugin Include
//require ( get_theme_file_path('../../plugins/redoy-protfolio-settings/redux-core/framework.php') );
//require ( get_theme_file_path('../../plugins/redoy-protfolio-settings/sample/config.php') );