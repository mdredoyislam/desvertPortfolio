<?php
/**
 * Silence is golden.
 *
 * @package Redux Pro
 */

echo null;
