<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package DesVert
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div id="page" class="site">

	<header id="masthead" class="site-header">
		<div class="container-fluid">
			<div class="row">
			<div class="col-lg-9 offset-lg-3">
			<div class="row align-items-center">
				<div class="col-lg-6">
					<div class="site-branding">
						<?php
							if ( is_front_page() && is_home() ) :
								?>
								<div class="site-logo"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php the_custom_logo(); ?></a></div>
								<?php
							else :
								?>
								<p class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></p>
								<?php
							endif;
						?>
					</div><!-- .site-branding -->
				</div>
				<div class="col-lg-4">
					<div class="header-top-social">
						<ul class="nav header-social-list justify-content-center">
							<li><a href="#"><i class="fa-brands fa-facebook-f"></i></a></li>
							<li><a href="#"><i class="fa-brands fa-linkedin-in"></i></a></li>
							<li><a href="#"><i class="fa-brands fa-pinterest-p"></i></a></li>
							<li><a href="#"><i class="fa-brands fa-instagram"></i></a></li>
						</ul>
					</div>
				</div>
				<div class="col-lg-2 text-center">
				<button type="button" class="btn btn-nav-toggle" data-toggle="modal" data-target=".bd-example-modal-sm"><i class="fa-solid fa-bars"></i></button>
				</div>
			</div>
			</div>
		</div>
	</header><!-- #masthead -->
