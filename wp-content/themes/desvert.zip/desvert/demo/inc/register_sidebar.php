<?php
    function eiser_register_sidebar_init() {
        register_sidebar( array(
            'name'          => __( 'Blog Sidebar 1', 'eiser' ),
            'id'            => 'eiser-bloag-sidebar-1',
            'description'   => __( 'Ths is our blog sidebar 1 description', 'eiser' ),
            'before_widget' => '<aside class="single_sidebar_widget post_category_widget"><ul class="list cat-list">',
            'after_widget'  => '</ul></aside>',
            'before_title'  => '<h4 class="widget_title">',
            'after_title'   => '</h4>',
        ) );
        register_sidebar( array(
            'name'          => __( 'Blog Sidebar 2', 'eiser' ),
            'id'            => 'eiser-bloag-sidebar-2',
            'description'   => __( 'Ths is our blog sidebar 1 description', 'eiser' ),
            'before_widget' => '<aside class="single_sidebar_widget post_category_widget"><ul class="list cat-list">',
            'after_widget'  => '</ul></aside>',
            'before_title'  => '<h4 class="widget_title">',
            'after_title'   => '</h4>',
        ) );
        register_sidebar( array(
            'name'          => __( 'Blog Sidebar 3', 'eiser' ),
            'id'            => 'eiser-bloag-sidebar-3',
            'description'   => __( 'Ths is our blog sidebar 1 description', 'eiser' ),
            'before_widget' => '<aside class="single_sidebar_widget tag_cloud_widget"><ul class="list">',
            'after_widget'  => '</ul></aside>',
            'before_title'  => '<h4 class="widget_title">',
            'after_title'   => '</h4>',
        ) );
        register_sidebar( array(
            'name'          => __( 'Blog Sidebar 4', 'eiser' ),
            'id'            => 'eiser-bloag-sidebar-4',
            'description'   => __( 'Ths is our blog sidebar 1 description', 'eiser' ),
            'before_widget' => '<aside class="single_sidebar_widget instagram_feeds">',
            'after_widget'  => '</aside>',
            'before_title'  => '<h4 class="widget_title">',
            'after_title'   => '</h4>',
        ) );
    }
    add_action( 'widgets_init', 'eiser_register_sidebar_init' );
?>