<?php
// eiser Assets Css & Js File Call
function eiser_assets() {
    // eiser Css All File Enquee
        wp_enqueue_style( "bootstrap", get_theme_file_uri( "/css/bootstrap.css" ), null, "1.0" );
        wp_enqueue_style( "linericon", get_theme_file_uri( "/vendors/linericon/style.css" ), null, "1.0" );
        wp_enqueue_style( "font-awesome", get_theme_file_uri( "/css/font-awesome.min.css" ), null, "1.0" );
        wp_enqueue_style( "themify-icons", get_theme_file_uri( "/css/themify-icons.css" ), null, "1.0" );
        wp_enqueue_style( "owl-carousel", get_theme_file_uri( "/vendors/owl-carousel/owl.carousel.min.css" ), null, "1.0" );
        wp_enqueue_style( "simpleLightbox", get_theme_file_uri( "/vendors/lightbox/simpleLightbox.css" ), null, "1.0" );
        wp_enqueue_style( "nice-select", get_theme_file_uri( "/vendors/nice-select/css/nice-select.css" ), null, "1.0" );
        wp_enqueue_style( "animate", get_theme_file_uri( "/vendors/animate-css/animate.css" ), null, "1.0" );
        wp_enqueue_style( "jquery-ui", get_theme_file_uri( "/vendors/jquery-ui/jquery-ui.css" ), null, "1.0" );
        wp_enqueue_style( "eiser-style", get_theme_file_uri( "/css/style.css" ), null, "1.0" );
        wp_enqueue_style( "responsive", get_theme_file_uri( "/css/responsive.css" ), null, "1.0" );
    
        wp_enqueue_style( "eiser-css", get_stylesheet_uri(), null, VERSION );
    
    // eiser Javascript All File Enquee
        wp_enqueue_script( "jquery-3.2.1", get_theme_file_uri( "/js/jquery-3.2.1.min.js" ), array( "jquery" ), "1.0", true );
        wp_enqueue_script( "popper", get_theme_file_uri( "/js/popper.js" ), array( "jquery" ), "1.0", true );
        wp_enqueue_script( "bootstrap", get_theme_file_uri( "/js/bootstrap.min.js" ), array( "jquery" ), "1.0", true );
        wp_enqueue_script( "stellar", get_theme_file_uri( "/js/stellar.js" ), array( "jquery" ), "1.0", true );
        wp_enqueue_script( "simpleLightbox", get_theme_file_uri( "/vendors/lightbox/simpleLightbox.min.js" ), array( "jquery" ), "1.0", true );
        wp_enqueue_script( "nice-select", get_theme_file_uri( "/vendors/nice-select/js/jquery.nice-select.min.js" ), array( "jquery" ), "1.0", true );
        wp_enqueue_script( "imagesloaded", get_theme_file_uri( "/vendors/isotope/imagesloaded.pkgd.min.js" ), array( "jquery" ), "1.0", true );
        wp_enqueue_script( "isotope-min", get_theme_file_uri( "/vendors/isotope/isotope-min.js" ), array( "jquery" ), "1.0", true );
        wp_enqueue_script( "owl-carousel", get_theme_file_uri( "/vendors/owl-carousel/owl.carousel.min.js" ), array( "jquery" ), "1.0", true );
        wp_enqueue_script( "jquery.ajaxchimp", get_theme_file_uri( "/js/jquery.ajaxchimp.min.js" ), array( "jquery" ), "1.0", true );
        wp_enqueue_script( "mail-script", get_theme_file_uri( "/js/mail-script.js" ), array( "jquery" ), "1.0", true );
        wp_enqueue_script( "jquery-ui", get_theme_file_uri( "/vendors/jquery-ui/jquery-ui.js" ), array( "jquery" ), "1.0", true );
        wp_enqueue_script( "theme", get_theme_file_uri( "/js/theme.js" ), array( "jquery" ), "1.0", true );
    }
    add_action( "wp_enqueue_scripts", "eiser_assets" );
?>