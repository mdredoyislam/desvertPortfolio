<div class="col-lg-4">
    <div class="blog_right_sidebar">
        <aside class="single_sidebar_widget search_widget">
            <?php get_search_form( true ); ?>
        </aside>
        <?php dynamic_sidebar('eiser-bloag-sidebar-1'); ?>
        <?php dynamic_sidebar('eiser-bloag-sidebar-2'); ?>
        <?php dynamic_sidebar('eiser-bloag-sidebar-3'); ?>
        <?php dynamic_sidebar('eiser-bloag-sidebar-4'); ?>

        <aside class="single_sidebar_widget instagram_feeds">
        <h4 class="widget_title">Instagram Feeds</h4>
        <ul class="instagram_row flex-wrap">
            <li>
                <a href="#">
                    <img class="img-fluid" src="<?php echo get_template_directory_uri(); ?>/img/instagram/widget-i1.png" alt="">
                </a>
            </li>
            <li>
                <a href="#">
                    <img class="img-fluid" src="<?php echo get_template_directory_uri(); ?>/img/instagram/widget-i2.png" alt="">
                </a>
            </li>
            <li>
                <a href="#">
                    <img class="img-fluid" src="<?php echo get_template_directory_uri(); ?>/img/instagram/widget-i3.png" alt="">
                </a>
            </li>
            <li>
                <a href="#">
                    <img class="img-fluid" src="<?php echo get_template_directory_uri(); ?>/img/instagram/widget-i4.png" alt="">
                </a>
            </li>
            <li>
                <a href="#">
                    <img class="img-fluid" src="<?php echo get_template_directory_uri(); ?>/img/instagram/widget-i5.png" alt="">
                </a>
            </li>
            <li>
                <a href="#">
                    <img class="img-fluid" src="<?php echo get_template_directory_uri(); ?>/img/instagram/widget-i6.png" alt="">
                </a>
            </li>
        </ul>
        </aside>


        <aside class="single_sidebar_widget newsletter_widget">
        <h4 class="widget_title">Newsletter</h4>

        <form action="#">
            <div class="form-group">
            <input type="email" class="form-control" placeholder="Enter email" required>
            </div>
            <button class="main_btn rounded-0 w-100" type="submit">Subscribe</button>
        </form>
        </aside>
    </div>
</div>