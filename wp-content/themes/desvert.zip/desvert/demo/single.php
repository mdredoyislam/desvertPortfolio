<?php get_header(); ?>
    <!--================Home Banner Area =================-->
    <section class="banner_area">
      <div class="banner_inner d-flex align-items-center">
        <div class="container">
          <div
            class="banner_content d-md-flex justify-content-between align-items-center"
          >
            <div class="mb-3 mb-md-0">
              <h2>Blog Details</h2>
              <p>Very us move be blessed multiply night</p>
            </div>
            <div class="page_link">
              <a href="index.html">Home</a>
              <a href="blog.html">Blog </a>
              <a href="single-blog.html">Blog Details</a>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--================End Home Banner Area =================-->

    <!--================Blog Area =================-->
	<section class="blog_area single-post-area section_gap">
			<div class="container">
					<div class="row">
							<div class="col-lg-8 posts-list">
                <?php
                if(have_posts()):
                  while(have_posts()):the_post();
                ?>
									<div class="single-post">
													<div class="feature-img">
                          <?php the_post_thumbnail("full",array('class' => 'img-fluid')); ?>
													</div>
											<div class="blog_details">
													<h2><?php the_title(); ?></h2>
                          <ul class="blog-info-link mt-3 mb-4">
                            <li><i class="ti-user"></i><?php the_category(','); ?></li>
                            <li><a href="#"><i class="ti-comments"></i><?php comments_popup_link(__('Leave a Comment', 'eiser'),__('1 Comment', 'eiser'),__('% Comments','eiser'),'',__('omments are off for this post','eiser')); ?></a></li>
                          </ul>
                          <?php the_content(); ?>
											</div>
                  </div>
                
                  <div class="navigation-top">
                    <div class="d-sm-flex justify-content-between text-center">
                      <p class="like-info"><span class="align-middle"><i class="ti-heart"></i></span> Lily and 4 people like this</p>
                      <div class="col-sm-4 text-center my-2 my-sm-0">
                        <ul class="blog-info-link">
                          <li><a href="#"><i class="ti-comment"></i><?php comments_popup_link(__('Comments', 'eiser'),__('1 Comment', 'eiser'),__('% Comments','eiser'),'',__('omments are off for this post','eiser')); ?></a></li>
                        </ul>
                      </div>
                      <ul class="social-icons">
                        <li><a href="#"><i class="ti-facebook"></i></a></li>
                        <li><a href="#"><i class="ti-twitter-alt"></i></a></li>
                        <li><a href="#"><i class="ti-dribbble"></i></a></li>
                        <li><a href="#"><i class="ti-wordpress"></i></a></li>
                      </ul>
                    </div>

                    <div class="navigation-area">
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-12 nav-left flex-row d-flex justify-content-start align-items-center">
                                <div class="thumb">
                                    <a href="#">
                                        <img class="img-fluid" src="img/blog/prev.jpg" alt="">
                                    </a>
                                </div>
                                <div class="arrow">
                                    <a href="#">
                                        <span class="ti-arrow-left text-white"></span>
                                    </a>
                                </div>
                                <div class="detials">
                                    <p>Prev Post</p>
                                    <a href="#">
                                        <h4>Space The Final Frontier</h4>
                                    </a>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-12 nav-right flex-row d-flex justify-content-end align-items-center">
                                <div class="detials">
                                    <p>Next Post</p>
                                    <a href="#">
                                        <h4>Telescopes 101</h4>
                                    </a>
                                </div>
                                <div class="arrow">
                                    <a href="#">
                                        <span class="ti-arrow-right text-white"></span>
                                    </a>
                                </div>
                                <div class="thumb">
                                    <a href="#">
                                        <img class="img-fluid" src="img/blog/next.jpg" alt="">
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                  </div>
                  
                  <div class="blog-author">
                    <div class="media align-items-center">
                      <?php echo get_avatar(get_the_author_meta("ID"),100); ?>
                      <div class="media-body">
                        <a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>">
                          <h4><?php echo esc_attr( get_the_author() ); ?></h4>
                        </a>
                        <p><?php echo esc_attr( the_author_meta('description')
                       ); ?></p>
                      </div>
                    </div>
                  </div>
                  <?php
                    if(comments_open() || get_comments_number()):
                      comments_template();
                    endif;
                  ?>
									<div class="comments-area">
											<h4>05 Comments</h4>
											<div class="comment-list">
                        <div class="single-comment justify-content-between d-flex">
                          <div class="user justify-content-between d-flex">
                              <div class="thumb">
                                  <img src="img/blog/c1.png" alt="">
                              </div>
                              <div class="desc">
                                  <p class="comment">
                                    Multiply sea night grass fourth day sea lesser rule open subdue female fill which them Blessed, give fill lesser bearing multiply sea night grass fourth day sea lesser 
                                  </p>

                                  <div class="d-flex justify-content-between">
                                    <div class="d-flex align-items-center">
                                      <h5>
                                        <a href="#">Emilly Blunt</a>
                                      </h5>
                                      <p class="date">December 4, 2017 at 3:12 pm </p>
                                    </div>

                                    <div class="reply-btn">
                                      <a href="#" class="btn-reply text-uppercase">reply</a>
                                    </div>
                                  </div>
                                  
                              </div>
                          </div>
                      </div>
											</div>
											<div class="comment-list">
                          <div class="single-comment justify-content-between d-flex">
                              <div class="user justify-content-between d-flex">
                                  <div class="thumb">
                                      <img src="img/blog/c2.png" alt="">
                                  </div>
                                  <div class="desc">
                                      <p class="comment">
                                        Multiply sea night grass fourth day sea lesser rule open subdue female fill which them Blessed, give fill lesser bearing multiply sea night grass fourth day sea lesser 
                                      </p>
    
                                      <div class="d-flex justify-content-between">
                                        <div class="d-flex align-items-center">
                                          <h5>
                                            <a href="#">Emilly Blunt</a>
                                          </h5>
                                          <p class="date">December 4, 2017 at 3:12 pm </p>
                                        </div>
    
                                        <div class="reply-btn">
                                          <a href="#" class="btn-reply text-uppercase">reply</a>
                                        </div>
                                      </div>
                                      
                                  </div>
                              </div>
                          </div>
											</div>
											<div class="comment-list">
                          <div class="single-comment justify-content-between d-flex">
                              <div class="user justify-content-between d-flex">
                                  <div class="thumb">
                                      <img src="img/blog/c3.png" alt="">
                                  </div>
                                  <div class="desc">
                                      <p class="comment">
                                        Multiply sea night grass fourth day sea lesser rule open subdue female fill which them Blessed, give fill lesser bearing multiply sea night grass fourth day sea lesser 
                                      </p>
    
                                      <div class="d-flex justify-content-between">
                                        <div class="d-flex align-items-center">
                                          <h5>
                                            <a href="#">Emilly Blunt</a>
                                          </h5>
                                          <p class="date">December 4, 2017 at 3:12 pm </p>
                                        </div>
    
                                        <div class="reply-btn">
                                          <a href="#" class="btn-reply text-uppercase">reply</a>
                                        </div>
                                      </div>
                                      
                                  </div>
                              </div>
                          </div>
											</div>
									</div>
									<div class="comment-form">
											<h4>Leave a Reply</h4>
											<form class="form-contact comment_form" action="#" id="commentForm">
                        <div class="row">
                          <div class="col-12">
                            <div class="form-group">
                                <textarea class="form-control w-100" name="comment" id="comment" cols="30" rows="9" placeholder="Write Comment"></textarea>
                            </div>
                          </div>
                          <div class="col-sm-6">
                            <div class="form-group">
                              <input class="form-control" name="name" id="name" type="text" placeholder="Name">
                            </div>
                          </div>
                          <div class="col-sm-6">
                            <div class="form-group">
                              <input class="form-control" name="email" id="email" type="email" placeholder="Email">
                            </div>
                          </div>
                          <div class="col-12">
                            <div class="form-group">
                              <input class="form-control" name="website" id="website" type="text" placeholder="Website">
                            </div>
                          </div>
                        </div>
                        <div class="form-group">
                          <button type="submit" class="main_btn">Send Message</button>
                        </div>
                      </form>
									</div>
                  <?php
                      endwhile;
                      wp_reset_postdata();
                    endif;
                  ?>
							</div>
              <?php get_sidebar(); ?>
					</div>
			</div>
	</section>
	<!--================Blog Area =================-->
<?php get_footer(); ?>