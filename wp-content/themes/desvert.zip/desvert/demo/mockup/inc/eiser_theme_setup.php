function eiser_theme_setup() {
    load_theme_textdomain( "eiser" );
    add_theme_support( "post-thumbnails" );
    add_theme_support( "title-tag" );
    add_theme_support( 'html5', array( 'search-form', 'comment-list' ) );
    add_theme_support( "post-formats", array( "image", "gallery", "quote", "audio", "video", "link" ) );
    add_editor_style( "/assets/css/editor-style.css" );
    //Menu Register
    register_nav_menu( "primary", __( "Primary Menu", "eiser" ) );
    //Image Size Support
    add_image_size("eiser-home-square",400,400,true);
}
//Menu Register
register_nav_menu( "primary", __( "Primary Menu", "eiser" ) );
register_nav_menu( "headertopmenu", __( "Header Top Menu", "eiser" ) );


//Theme Logo Support Customizer
add_theme_support( 'custom-logo', array(
    'height'               => 40,
    'width'                => 140,
    'flex-height'          => true,
    'flex-width'           => true,
    'header-text'          => array( 'site-title', 'site-description' ),
    'unlink-homepage-logo' => true,
) );
add_action( "after_setup_theme", "eiser_theme_setup" );