<ul class="blog-info-link">
    <li><i class="far fa-user"></i><?php the_category(','); ?></li>
    <li><a href="#"><i class="far fa-comments"></i><?php comments_popup_link(__('Leave a Comment', 'redoyit'),__('1 Comment', 'redoyit'),__('% Comments','redoyit'),'',__('omments are off for this post','redoyit')); ?></a></li>
</ul>
//Comment
<ul class="blog-info-link">
  <li><a href="#"><i class="ti-user"></i> <?php echo get_the_tag_list('',' , ',''); ?></a>
  </li>
  <li>
    <?php
        $eicher_cn = get_comments_number();
        if(1 == $eicher_cn){
      ?>
      <a href="<?php echo get_comment_link(); ?>"><i class="ti-comments"></i> <?php _e( "1 Comment", "alpha" ); ?></a>
      <?php
      }else{
      ?>
      <a href="<?php echo get_comment_link(); ?>"><i class="ti-comments"></i> 
      <?php echo $eicher_cn ." ".__("Comments","alpha"); ?></a>
      <?php
      }
    ?>
  </li>
</ul>