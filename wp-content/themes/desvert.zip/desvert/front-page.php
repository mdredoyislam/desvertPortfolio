<?php
/**
 * Template Name: Home
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package DesVert
 */

get_header();
?>
<section id="desvert-tagline">
    <div class="shape-1"></div>
    <div class="shape-2"></div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-6 offset-lg-3">
                <div class="tagline-contents">
                    <h3>best design agency:</h3>
                    <h1>we help our clients to bring their ideas into reality</h1>
                </div>
            </div>
        </div>
    </div>
</section>
<section id="services-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <div class="row mb-4">
                    <div class="col-lg-12">
                        <h4 class="section-sub-title">our key services</h4>
                        <h3 class="section-title">what we offer</h3>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6">
                        <a href="#" class="wrapper-link">
                            <div class="single-services-wrap">
                                <h4>UX Design</h4>
                                <p>We are offering out-of-the-box web design solutions to boost up the brands of our dedicated clients worldwide.</p>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-6">
                        <a href="#" class="wrapper-link">
                            <div class="single-services-wrap">
                                <h4>publication design</h4>
                                <p>We create publication design such as company brochure, profile, proposal, annual report to reach next level of the business.</p>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-6">
                        <a href="#" class="wrapper-link">
                            <div class="single-services-wrap">
                                <h4>email template design</h4>
                                <p>We contribute full-cycle customized web development services with cross stx platform solutions for a seamless website</p>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-6">
                        <a href="#" class="wrapper-link">
                            <div class="single-services-wrap">
                                <h4>promotional design</h4>
                                <p>With our groundbreaking ideas and strategies, we will create and uphold your brand on your all kind of promotional activities.</p>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-6">
                        <a href="#" class="wrapper-link">
                            <div class="single-services-wrap">
                                <h4>front end development</h4>
                                <p>By analyzing your business, we design websites that increase conversion rates and produce positive results.</p>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-6">
                        <a href="#" class="wrapper-link">
                            <div class="single-services-wrap">
                                <h4>wordpress development</h4>
                                <p>Our custom web development will reduce downtime and increase efficiency so users do not have to worry about their websites.</p>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-lg-4"></div>
        </div>
    </div>
    <div class="services-slider-wrapper">
        <div class="owl-carousel services-slider">
            <div class="slider-item">
                <img src="<?php echo get_template_directory_uri(); ?>/slider-item.png" alt="Slider-item">
                <h3 class="slider-item-text">we make lovely designs</h3>
            </div>
            <div class="slider-item">
                <img src="<?php echo get_template_directory_uri(); ?>/slider-item.png" alt="Slider-item">
                <h3 class="slider-item-text">we make lovely designs</h3>
            </div>
            <div class="slider-item">
                <img src="<?php echo get_template_directory_uri(); ?>/slider-item.png" alt="Slider-item">
                <h3 class="slider-item-text">we make lovely designs</h3>
            </div>
        </div>
    </div>
</section>
<section id="make-appoinment">
    <div class="container">
        <div class="row">
            <div class="col-lg-11 offset-lg-1">
                <h4 class="section-sub-title">thinking about your next project?</h4>
                <h3 class="section-title">Let’s start your project now, Make an appointment for discuss with our expert consultant.</h3>
                <button class="appoinment-btn" type="button" data-toggle="modal" data-target="#exampleModalCenter">make appointment<i class="fas fa-arrow-right"></i></button>
            </div>
        </div>
    </div>
</section>
<section id="portfolio-gallery">
    <div class="portfolio-gallery-wrapper">
        <a href="<?php echo get_template_directory_uri(); ?>/img/img1.png" class="portfolio-item">
            <img src="<?php echo get_template_directory_uri(); ?>/img/img1.png" alt="gallery-item">
        </a>
        <a href="<?php echo get_template_directory_uri(); ?>/img/img2.png" class="portfolio-item">
            <img src="<?php echo get_template_directory_uri(); ?>/img/img2.png" alt="gallery-item">
        </a>
        <a href="<?php echo get_template_directory_uri(); ?>/img/img3.png" class="portfolio-item">
            <img src="<?php echo get_template_directory_uri(); ?>/img/img3.png" alt="gallery-item">
        </a>
        <a href="<?php echo get_template_directory_uri(); ?>/img/img4.png" class="portfolio-item">
            <img src="<?php echo get_template_directory_uri(); ?>/img/img4.png" alt="gallery-item">
        </a>
        <a href="<?php echo get_template_directory_uri(); ?>/img/img5.png" class="portfolio-item">
            <img src="<?php echo get_template_directory_uri(); ?>/img/img5.png" alt="gallery-item">
        </a>
        <a href="<?php echo get_template_directory_uri(); ?>/img/img6.png" class="portfolio-item">
            <img src="<?php echo get_template_directory_uri(); ?>/img/img6.png" alt="gallery-item">
        </a>
        <a href="<?php echo get_template_directory_uri(); ?>/img/img8.png" class="portfolio-item">
            <img src="<?php echo get_template_directory_uri(); ?>/img/img8.png" alt="gallery-item">
        </a>
        <a href="<?php echo get_template_directory_uri(); ?>/img/img7.png" class="portfolio-item">
            <img src="<?php echo get_template_directory_uri(); ?>/img/img7.png" alt="gallery-item">
        </a>
    </div>
</section>
<section id="explore-more">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-7">
                <div class="explore-text">
                    <p>We will be happy to let you know about our recent projects</p>
                </div>
            </div>
            <div class="col-lg-5">
                <div class="explore-button text-end">
                    <a href="#" class="btn explore-more">explore more <i class="fas fa-arrow-right"></i></a>
                </div>
            </div>
        </div>
    </div>
</section>
<section id="testimonial">
    <div class="container">
        <div class="row">
            <div class="col-lg-10 offset-lg-1">
                <h4 class="section-sub-title">testimonial</h4>
                <h3 class="section-title">what customer says</h3>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-9 offset-lg-1" style="padding-left: 90px">
            <div class="slide-content">
                <div class="owl-carousel">
                    <div class="testimonial-items">
                        <p class="test-desc">We are offering out-of-the-box web design solutions to boost up the brands of our dedicated clients worldwide. We are offering out-of-the-box web design solutions to boost up the brands of our dedicated clients worldwide.</p>
                        <h4 class="user-name">John doe</h4>
                        <span class="user-designation">managing director, esfera media</span>
                    </div>
                    <div class="testimonial-items">
                        <p class="test-desc">We are offering out-of-the-box web design solutions to boost up the brands of our dedicated clients worldwide. We are offering out-of-the-box web design solutions to boost up the brands of our dedicated clients worldwide.</p>
                        <h4 class="user-name">John doe</h4>
                        <span class="user-designation">managing director, esfera media</span>
                    </div>
                    <div class="testimonial-items">
                        <p class="test-desc">We are offering out-of-the-box web design solutions to boost up the brands of our dedicated clients worldwide. We are offering out-of-the-box web design solutions to boost up the brands of our dedicated clients worldwide.</p>
                        <h4 class="user-name">John doe</h4>
                        <span class="user-designation">managing director, esfera media</span>
                    </div>
                    <div class="testimonial-items">
                        <p class="test-desc">We are offering out-of-the-box web design solutions to boost up the brands of our dedicated clients worldwide. We are offering out-of-the-box web design solutions to boost up the brands of our dedicated clients worldwide.</p>
                        <h4 class="user-name">John doe</h4>
                        <span class="user-designation">managing director, esfera media</span>
                    </div>
                    <div class="testimonial-items">
                        <p class="test-desc">We are offering out-of-the-box web design solutions to boost up the brands of our dedicated clients worldwide. We are offering out-of-the-box web design solutions to boost up the brands of our dedicated clients worldwide.</p>
                        <h4 class="user-name">John doe</h4>
                        <span class="user-designation">managing director, esfera media</span>
                    </div>
                    <div class="testimonial-items">
                        <p class="test-desc">We are offering out-of-the-box web design solutions to boost up the brands of our dedicated clients worldwide. We are offering out-of-the-box web design solutions to boost up the brands of our dedicated clients worldwide.</p>
                        <h4 class="user-name">John doe</h4>
                        <span class="user-designation">managing director, esfera media</span>
                    </div>
                </div>
                <div id="testslidecounter"></div>
            </div>
        </div>
    </div>
</section>
<section id="counter-section">
    <div class="container">
        <div class="row">
            <div class="counter-item">
                <div class="row">
                    <div class="col-lg-6">
                        <span class="counter"><span class="counterup">2.5</span>K+</span>
                    </div>
                    <div class="col-lg-6">
                        <div class="counter-text">
                            <span>projects</span>
                            <h4>completed</h4>
                        </div>
                    </div>
                </div>
            </div>
            <div class="counter-item">
                <div class="row">
                    <div class="col-lg-6">
                        <span class="counter"><span class="counterup">500</span>+</span>
                    </div>
                    <div class="col-lg-6">
                        <div class="counter-text">
                            <span>served</span>
                            <h4>customers</h4>
                        </div>
                    </div>
                </div>
            </div>
            <div class="counter-item">
                <div class="row">
                    <div class="col-lg-6">
                        <span class="counter"><span class="counterup">30</span>+</span>
                    </div>
                    <div class="col-lg-6">
                        <div class="counter-text">
                            <span>master</span>
                            <h4>minds</h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php
get_footer();
?>
